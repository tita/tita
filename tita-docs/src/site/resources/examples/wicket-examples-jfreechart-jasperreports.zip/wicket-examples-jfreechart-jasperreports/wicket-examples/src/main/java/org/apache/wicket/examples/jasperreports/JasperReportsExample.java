package org.apache.wicket.examples.jasperreports;

import java.util.HashMap;

import javax.servlet.ServletContext;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

import org.apache.wicket.examples.WicketExamplePage;
import org.apache.wicket.markup.html.link.ResourceLink;
import org.apache.wicket.protocol.http.WebApplication;

public final class JasperReportsExample extends WicketExamplePage {

	public JasperReportsExample() {
		//compiling reports should be done by maven plugin, but for now:
		ServletContext context = ((WebApplication) getApplication()).getServletContext();
		
		//set values for parameter in report
		HashMap<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put("paramName", "paramValue");
		
		JasperDesign design;
		JasperReport report = null;
		JasperPrint jasperPrint = null;
		
		try {
			design = JRXmlLoader.load(context.getRealPath("/reports/simpleReport.jrxml"));
			report = JasperCompileManager.compileReport(design);
			jasperPrint = JasperFillManager.fillReport(report, parameterMap, new JREmptyDataSource());
		} catch (JRException e) {
			e.printStackTrace();
		}
		
		JasperReportsResource jr = new JasperReportsResource(jasperPrint);
		add(new ResourceLink("linkToPdf", jr));
	}
}
