package org.apache.wicket.examples.jasperreports;

import java.io.ByteArrayOutputStream;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import org.apache.wicket.markup.html.DynamicWebResource;

public class JasperReportsResource extends DynamicWebResource {

	private JasperPrint print;
	
	public JasperReportsResource(JasperPrint print) {
		this.print = print;
	}
	
	@Override
	protected ResourceState getResourceState() {
		return new ResourceState() {
            public String getContentType() {
               return "application/pdf";
            }

            public byte[] getData() {
            	JRPdfExporter exporter = new JRPdfExporter();
            	
    			ByteArrayOutputStream os = new ByteArrayOutputStream();
    			exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
    			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, os);

    			try {
					exporter.exportReport();
				} catch (JRException e) {
					e.printStackTrace();
				}
    			return os.toByteArray();
            }
         };
	}

}
