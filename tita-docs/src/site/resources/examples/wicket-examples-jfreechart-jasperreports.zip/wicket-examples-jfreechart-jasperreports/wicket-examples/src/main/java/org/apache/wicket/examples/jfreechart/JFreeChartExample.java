package org.apache.wicket.examples.jfreechart;

import org.apache.wicket.examples.WicketExamplePage;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public final class JFreeChartExample extends WicketExamplePage {

	public JFreeChartExample() {
		DefaultPieDataset d = new DefaultPieDataset();
		d.setValue("JavaWorld", new Integer(75));
		d.setValue("Other", new Integer(25));
		JFreeChart chart = ChartFactory.createPieChart("Sample Pie Chart", d,
                 true,		// Show legend  
                 true,		// Show tooltips
                 true);		// Show urls
		
		add(new JFreeChartImage("image", chart, 300, 300));
	}

}
