package org.apache.wicket.examples.jfreechart;

import org.apache.wicket.Page;
import org.apache.wicket.examples.WicketExampleApplication;

public class JFreeChartApplication extends WicketExampleApplication {

	public JFreeChartApplication() {

    }
	
	@Override
	public Class<? extends Page> getHomePage() {
		return JFreeChartExample.class;
	}		
}
