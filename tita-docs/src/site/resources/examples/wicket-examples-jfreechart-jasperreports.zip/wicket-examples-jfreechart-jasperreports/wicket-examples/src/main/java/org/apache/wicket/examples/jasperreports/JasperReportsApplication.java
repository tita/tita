package org.apache.wicket.examples.jasperreports;

import org.apache.wicket.Page;
import org.apache.wicket.examples.WicketExampleApplication;
import org.apache.wicket.examples.jasperreports.JasperReportsExample;

public class JasperReportsApplication extends WicketExampleApplication {

	public JasperReportsApplication() {

    }
	
	@Override
	public Class<? extends Page> getHomePage() {
		return JasperReportsExample.class;
	}		

}
